package Poli;//Decimos que la clase esta en este paquete
import java.util.Scanner;//Aqui importamos la libreria para poder utilizar el Scanner
public abstract class Operaciones_ClasePadre { //Aqui ponemos abstracta la clase padre que es la de operaciones
    protected int a,b,resultado;//Declaramos las variables y las declaramos protegidos 
    Scanner entrada = new Scanner(System.in);//Aqui creamos el objeto para la entrada de datos del Scanner
    public void PedirDatos(){//Aqui Definimos el metodo que llevaria
        System.out.print("Ingrese el primer valor: ");//Aqui mandamos el mensaje para pedir un valor
        a = entrada.nextInt();// Aqui pedimos el dato por teclado para que el usuario lo coloque
        System.out.print("Ingrese el segundo valor: ");//Aqui mandamos el mensaje para pedir un valor
        b = entrada.nextInt();// Aqui pedimos el dato por teclado para que el usuario lo coloque
    }//Cerramos el metodo
    public abstract void Operaciones();//Aqui decalramos el metodo operaciones que es el que va a heredar a las demas clases
    public void MostrarResultado(){//Aqui declaramos el metodo para mostrar el resultado
        System.out.println("El resultado es de: "+resultado);//Aqui vamos a imprimir el resultado
    }//Aqui cerramos el metodo
}//Aqui cerramos la clase
