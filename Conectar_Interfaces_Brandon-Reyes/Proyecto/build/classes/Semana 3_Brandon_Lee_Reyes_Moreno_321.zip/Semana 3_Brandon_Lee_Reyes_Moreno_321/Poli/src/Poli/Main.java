package Poli;//Decimos que la clase esta en este paquete
public class Main {//ESta es la clase principal
    public static void main(String[]args){//Este es el metodo principal
        Operaciones_ClasePadre obj = new Suma_claseHija(); //Creo el objeto de operaciones de clase padre y de Suma Clase Hija
        obj.PedirDatos(); //Mandamos llamar al metodo de Pedir Datos
        obj.Operaciones(); //Madamos llamar a metodo de Operaciones
        obj.MostrarResultado(); //Mandamos llamar al metodo Mostrar Resultado
        
        Operaciones_ClasePadre obj1 = new Resta_ClaseHija();//Creo el objeto de operaciones de clase padre y de Resta Clase Hija
        obj1.PedirDatos();//Mandamos llamar al metodo de Pedir Datos
        obj1.Operaciones();//Madamos llamar a metodo de Operaciones
        obj1.MostrarResultado();//Mandamos llamar al metodo Mostrar Resultado
    }
}
