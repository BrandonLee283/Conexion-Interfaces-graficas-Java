package Poli;//Aqui decimos que la clase estara en este paquete
public class Resta_ClaseHija extends Operaciones_ClasePadre{// Aqui definimos la clase y le pusimos el extends para que heredara de la clase padre
    @Override//Esto es para saber que vamos a sobreescribir algo
    public void Operaciones(){//Aqui sobreescribimos el metodo de operaciones que se hereda de la clase padre
        resultado = a - b;//Aqui hacemos la operacion correspondiente
    }//Aqui cerramos el metodo
}//Aqui cerramos la clase
